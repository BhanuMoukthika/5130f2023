use Google authenticator app
Install the necessary packages and it will run in your local host
Bhanu_Devarapu@student.uml.edu


									Week-3 Report

In this week, we did the user authentication and validated in Local terminal via Node.js. Initially, installed all the required packages like  bcrypt, mysql, jsonwebtokens. Secondly, running XAMPP( Apache server and SQL). Then on running this command "npm start", my spp.js will run  and give me a port number. Further, on running that port number within the localhost, my webpage will open and my signup for and  Login form will be displayed.

However, On filling up the signup form and submitting the form, I will get a display message called "Registered successfully". All my data will be displayed in my Local terminal too. This is just checking that the user details is taken correctly and validating it or not. In Future, will develop more precisely and validate and store the data in my database.


Note: The data which is stored i have attached a snapshot along with the signup successful snapshot.


Note: If you want to run the above process and validate , download node.js and download "XAMPP" and run MySQL and Apache. Then in your visual studio code terminal follow the "packages-installed.txt" and give command  "npm start". Then you get a port number. So, you get port number as 5001. Then type  "localhost:5001" in your brower and then signup. You see the results.

Note: As,nodemodules has bigger size and cannot be uploaded in weblab.cs.uml.edu and GitHub I have put a zip file for the cs servers as nodemodules.zip and in GitHub i have uploaded whole file as a zip file.




-Thankyou


